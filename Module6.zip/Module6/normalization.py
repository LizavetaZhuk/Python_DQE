import re


# function to count whitespaces in the text
def whs_count_func(text):
    whitespacecount = len(re.findall("\s", text))
    return f'There are {whitespacecount} whitespaces in the homework.'


# function to normalize text to letter case point of view
def normalize_func(text):
    halffinaltext = """"""
    finaltext = ''

    # capitalize first letters at the beginning of the line (after tab)
    for sentence in text.split('\n'):
        halffinaltext += sentence.capitalize() + '\n'

    # capitalize first letters in the middle of the text (after dot)
    for item in halffinaltext.split('. '):
        finaltext += item[0].upper() + item[1:] + '. '
    finaltext = finaltext[:-2]  # remove last unnecessary dot
    return finaltext


# function to replace mistake 'iz' with correct 'is'
def replace_iz_func(text):
    lowerstring = text.lower()
    stringwithoutiz = lowerstring.replace(' iz ', ' is ')
    return stringwithoutiz


# function ti prepare new sentence from last words of all sentences and add it to the middle of text
def add_sentence_func(text):
    lowertext = text.lower()
    last_words = re.findall(r"\w+(?=[.])", lowertext)
    addsentence = ' '.join(last_words) + '.'

    position = lowertext.index('paragraph.')  # index of first letter in the word paragraph.
    newtext = lowertext[:position + 10] + ' ' + addsentence + lowertext[position + 10:]
    return newtext
